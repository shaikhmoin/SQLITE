//
//  ViewController.swift
//  mysqllite
//
//  Created by MACOS on 6/16/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    var arr = [Any]()
    var id = 0
    
    @IBOutlet var tbl: UITableView!
    @IBOutlet var txtid: UITextField!
    @IBOutlet var txtname: UITextField!
    @IBOutlet var txtadd: UITextField!
    @IBOutlet var insert: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bind()
    
    }

    func bind() {
        let obj = dbclass();
        
        let query = "select * from tblemp";
        
        arr = obj.getdata(query: query);
        
        print(arr);
    }
    @IBAction func btnInsert(_ sender: Any) {
        
        if id == 0
        {
        let obj = dbclass()
        
        let query = "insert into tblemp(eid,ename,eadd)values('\(txtid.text!)','\(txtname.text!)','\(txtadd.text!)')"
        
        let st = obj.dboperation(query: query)
        bind()
        tbl.reloadData()
        
        if st == true
        {
            print("Added successfully")
        }
        else
        {
            print("not added")
        }
        }
        else
        {
            print("updated button")
            id = 0
            insert.setTitle("Insert", for: .normal)
            bind()
            tbl.reloadData()
            
            let obj = dbclass()
            
            let query = String(format: "update tblemp set ename = '%@',eadd = '%@' where eid = '%@'",txtname.text!,txtadd.text!,txtid.text!)
            
            let st = obj.dboperation(query: query)
            bind()
            tbl.reloadData()
            if st == true
            {
                print("Updated successfully")
            }
            else
            {
                print("Not updated")
            }

        }
    }
    
    
    
    @IBAction func btnUpdate(_ sender: Any) {
    
        let obj = dbclass()
        
        let query = String(format: "update tblemp set ename = '%@',eadd = '%@' where eid = '%@'",txtname.text!,txtadd.text!,txtid.text!)
        
        let st = obj.dboperation(query: query)
        bind()
        tbl.reloadData()
        if st == true
        {
            print("Updated successfully")
        }
        else
        {
            print("Not updated")
        }
    }
    
    @IBAction func btndelete(_ sender: Any) {
     
        let obj = dbclass()
        
        let query = String(format: "delete from tblemp where eid = '%@'",txtid.text!)
        
        let st = obj.dboperation(query: query)
        bind()
        tbl.reloadData()
        
        if st == true
        {
            print("Delete successfully")
        }
        else
        {
            print("Not deleted")
        }
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        let dicfinal = arr[indexPath.section] as! [String]
        cell?.textLabel?.text = dicfinal[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let dic = arr[indexPath.section] as! [String];
        
        let empid = dic[0];
        
        let obj = dbclass();

        let query = "delete from  tblemp where eid = '\(empid)'";
        
        let st = obj.dboperation(query: query);
        
        if st == true {
            
            arr.remove(at: indexPath.section);
            
            tbl.reloadData();
        }

    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj = dbclass()
        
        let dic = arr[indexPath.section] as! [String]
        print(dic)
        let s = dic[0]
        print(s)
        let query = "select * from tblemp where eid = '\(s)'"
        
        let st = obj.getdata(query: query)
    
        txtid.text = dic[0]
        txtname.text = dic[1];
        txtadd.text = dic[2];
        id = 1
        insert.setTitle("update", for: .normal)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

